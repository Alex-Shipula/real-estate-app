export interface MapGoogleProps {
    center: {
        lat: number,
        lng: number
    },
    zoom: number
};