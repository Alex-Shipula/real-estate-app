
//import styles from './Wallet.module.css';

function Wallet(): JSX.Element {
	return (
		<h1>Wallet</h1>
	);
}
export default Wallet;