
//import styles from './LogIn.module.css';

function LogIn(): JSX.Element {
	return (
		<h1>LOGIN</h1>
	);
}
export default LogIn;