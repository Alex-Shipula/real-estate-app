
//import styles from './404.module.css';

function Error404(): JSX.Element {
	return (
		<h1>404 - Not Found!</h1>
	);
}
export default Error404;