
//import styles from './MyTokens.module.css';

function MyTokens(): JSX.Element {
	return (
		<h1>MyTokens</h1>
	);
}
export default MyTokens;