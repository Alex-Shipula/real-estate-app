
//import styles from './Blog.module.css';

function Blog(): JSX.Element {
	return (
		<h1>BLOG</h1>
	);
}
export default Blog;