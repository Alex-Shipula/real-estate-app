
//import styles from './Dashboard.module.css';

function Dashboard(): JSX.Element {
	return (
		<h1>Dashboard</h1>
	);
}
export default Dashboard;